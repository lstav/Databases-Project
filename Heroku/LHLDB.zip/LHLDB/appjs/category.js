function Category(id, name, productList){
	this.id=id;
	this.name= name;
	this.productList=productList;
	this.toJSON = toJSON;
}
