function Account(afname, alname, aaccountnumber, aemail, apassword, ausername, ashipping, abilling, accard, rank){
	this.aid = "";
	this.afname = afname;
	this.alname = alname;
	this.aaccountnumber = aaccountnumber;
	this.aemail = aemail;
	this.apassword = apassword;
	this.ausername = ausername;
	this.ashipping = ashipping;
	this.abilling = abilling;
	this.accard = accard;
	this.rank = rank;
	this.toJSON = toJSON;
}
