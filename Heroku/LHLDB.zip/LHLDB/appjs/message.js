function Message(sid,rid, mText){
	this.mid = "";
	this.sid = sid;
	this.rid = rid;
	this.mText = mText;
	this.toJSON = toJSON;
}
