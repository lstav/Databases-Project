function Address(address){
	this.addressid = "";
	this.address = address;
	this.toJSON = toJSON;
}
