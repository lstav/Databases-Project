function History(aid, productList, purchased){
	this.hid = "";
	this.aid = aid;
	this.productList = productList;
	this.purchased =purchased;
	this.toJSON = toJSON;
}
