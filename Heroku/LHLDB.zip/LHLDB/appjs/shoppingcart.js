function ShoppingCart(aid, productList){
	this.scid = "";
	this.aid = aid;
	this.productList = productList;
	this.toJSON = toJSON;
}
